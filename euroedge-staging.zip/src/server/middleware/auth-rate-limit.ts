import rateLimit, { ipKeyGenerator } from 'express-rate-limit';

const DEFAULT_LOGIN_WINDOW_MS = 15 * 60 * 1000;
const DEFAULT_LOGIN_MAX_ATTEMPTS = 5;
const UNKNOWN_USER = 'unknown-user';
const TOO_MANY_ATTEMPTS_MSG = 'Too many login attempts. Please try again later.';

const parsePositiveInt = (rawValue: string | undefined, fallback: number): number => {
  const parsed = Number.parseInt(rawValue ?? '', 10);
  if (Number.isNaN(parsed) || parsed <= 0) {
    return fallback;
  }
  return parsed;
};

const loginWindowMs = parsePositiveInt(
  process.env.LOGIN_RATE_LIMIT_WINDOW_MS,
  DEFAULT_LOGIN_WINDOW_MS
);
const loginMaxAttempts = parsePositiveInt(
  process.env.LOGIN_RATE_LIMIT_MAX_ATTEMPTS,
  DEFAULT_LOGIN_MAX_ATTEMPTS
);

const getUsernameRateLimitKey = (username: unknown): string => {
  if (typeof username !== 'string') {
    return UNKNOWN_USER;
  }
  const normalized = username.trim().toLowerCase();
  return normalized.length > 0 ? normalized : UNKNOWN_USER;
};

export const loginRateLimiter = rateLimit({
  windowMs: loginWindowMs,
  limit: loginMaxAttempts,
  standardHeaders: 'draft-8',
  legacyHeaders: false,
  // Include attempted username in the key to reduce lockout blast-radius.
  keyGenerator: (req) => {
    const ipKey = req.ip ? ipKeyGenerator(req.ip) : 'unknown-ip';
    return `${ipKey}:${getUsernameRateLimitKey((req.body as { username?: unknown; }).username)}`;
  },
  // Only failed attempts consume the budget, so a real operator is never
  // locked out by their own successful sign-ins.
  skipSuccessfulRequests: true,
  requestWasSuccessful: (_req, res) => res.statusCode < 400,
  handler: (_req, res, _next, options) => {
    const message = typeof options.message === 'string'
      ? options.message
      : TOO_MANY_ATTEMPTS_MSG;
    res.status(options.statusCode).send(message);
  },
  message: TOO_MANY_ATTEMPTS_MSG,
});
